package pl.kamil.teleport

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.Locale
import kotlin.random.Random

/**
 * Serwis, który co sekundę "wstrzykuje" wybraną lokalizację do systemu.
 * Działa w tle z powiadomieniem, więc możesz przełączyć się na Bumpa.
 */
class MockLocationService : Service() {

    companion object {
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        const val ACTION_STOP = "pl.kamil.teleport.STOP"
        private const val CHANNEL_ID = "teleport"
        private const val NOTIF_ID = 1

        @Volatile
        var isRunning = false
            private set
    }

    private lateinit var lm: LocationManager
    private lateinit var fused: FusedLocationProviderClient
    private val handler = Handler(Looper.getMainLooper())
    private val addedProviders = mutableListOf<String>()
    private var lat = 0.0
    private var lon = 0.0

    private val tick = object : Runnable {
        override fun run() {
            pushLocation()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        fused = LocationServices.getFusedLocationProviderClient(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent == null || !intent.hasExtra(EXTRA_LAT)) {
            stopSelf()
            return START_NOT_STICKY
        }
        lat = intent.getDoubleExtra(EXTRA_LAT, lat)
        lon = intent.getDoubleExtra(EXTRA_LON, lon)

        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        )

        if (!isRunning) {
            if (!setupProviders()) {
                Toast.makeText(
                    this,
                    "Ustaw Teleport jako aplikację do pozorowania lokalizacji w Opcjach programisty",
                    Toast.LENGTH_LONG
                ).show()
                stopSelf()
                return START_NOT_STICKY
            }
            isRunning = true
            handler.post(tick)
        } else {
            // Zmiana miejsca w trakcie działania
            pushLocation()
        }
        return START_REDELIVER_INTENT
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun setupProviders(): Boolean {
        val providers = mutableListOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        if (Build.VERSION.SDK_INT >= 31) providers.add(LocationManager.FUSED_PROVIDER)

        for (p in providers) {
            try {
                try { lm.removeTestProvider(p) } catch (_: Exception) {}
                lm.addTestProvider(
                    p, false, false, false, false, true, true, true,
                    Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
                lm.setTestProviderEnabled(p, true)
                addedProviders.add(p)
            } catch (e: SecurityException) {
                // Aplikacja nie jest wybrana w Opcjach programisty
                return false
            } catch (_: Exception) {
                // Ten provider może nie istnieć na danym telefonie – pomijamy
            }
        }

        // Google Play Services (z tego korzysta większość aplikacji, w tym Bump)
        try { fused.setMockMode(true) } catch (_: Exception) {}

        return addedProviders.isNotEmpty()
    }

    @SuppressLint("MissingPermission")
    private fun pushLocation() {
        // Malutkie drganie (~1 m), żeby lokalizacja wyglądała naturalnie
        val jLat = lat + (Random.nextDouble() - 0.5) * 0.00001
        val jLon = lon + (Random.nextDouble() - 0.5) * 0.00001

        for (p in addedProviders) {
            try { lm.setTestProviderLocation(p, makeLocation(p, jLat, jLon)) } catch (_: Exception) {}
        }
        try { fused.setMockLocation(makeLocation("fused", jLat, jLon)) } catch (_: Exception) {}
    }

    private fun makeLocation(provider: String, la: Double, lo: Double) = Location(provider).apply {
        latitude = la
        longitude = lo
        altitude = 120.0
        accuracy = 4f
        speed = 0f
        bearing = 0f
        time = System.currentTimeMillis()
        elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
        verticalAccuracyMeters = 3f
        speedAccuracyMetersPerSecond = 0.1f
        bearingAccuracyDegrees = 1f
    }

    @SuppressLint("MissingPermission")
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        for (p in addedProviders) {
            try { lm.setTestProviderEnabled(p, false) } catch (_: Exception) {}
            try { lm.removeTestProvider(p) } catch (_: Exception) {}
        }
        addedProviders.clear()
        try { fused.setMockMode(false) } catch (_: Exception) {}
        isRunning = false
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Teleport", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MockLocationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Teleport działa")
            .setContentText(String.format(Locale.US, "Jesteś w: %.5f, %.5f", lat, lon))
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stopIntent)
            .build()
    }
}
