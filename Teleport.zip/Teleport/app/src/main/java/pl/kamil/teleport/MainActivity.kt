package pl.kamil.teleport

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.location.Criteria
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var info: TextView
    private lateinit var startBtn: Button
    private lateinit var coords: EditText
    private var marker: Marker? = null
    private var point: GeoPoint? = null
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("teleport", MODE_PRIVATE) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) startMock()
            else toast("Bez dostępu do lokalizacji to nie zadziała")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName
        setContentView(R.layout.activity_main)

        map = findViewById(R.id.map)
        info = findViewById(R.id.info)
        startBtn = findViewById(R.id.start)
        coords = findViewById(R.id.coords)

        // Karta nie chowa się pod paskiem nawigacji
        val card = findViewById<View>(R.id.card)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            card.updateLayoutParams<ViewGroup.MarginLayoutParams> { bottomMargin = bars.bottom + dp(16) }
            insets
        }

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                setPoint(p); return true
            }
            override fun longPressHelper(p: GeoPoint): Boolean = false
        }))

        // Przywróć ostatnio wybrane miejsce
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (lat != null && lon != null) {
            val p = GeoPoint(lat, lon)
            setPoint(p, save = false)
            map.controller.setZoom(16.0)
            map.controller.setCenter(p)
        } else {
            map.controller.setZoom(6.0)
            map.controller.setCenter(GeoPoint(52.0, 19.0)) // Polska
        }

        findViewById<Button>(R.id.go).setOnClickListener {
            val parts = coords.text.toString().split(",", " ", ";").filter { it.isNotBlank() }
            val la = parts.getOrNull(0)?.toDoubleOrNull()
            val lo = parts.getOrNull(1)?.toDoubleOrNull()
            if (la == null || lo == null || la !in -90.0..90.0 || lo !in -180.0..180.0) {
                toast("Wpisz np. 52.2297, 21.0122")
                return@setOnClickListener
            }
            val p = GeoPoint(la, lo)
            setPoint(p)
            map.controller.animateTo(p, 16.0, 800L)
        }

        startBtn.setOnClickListener {
            if (MockLocationService.isRunning) stopMock() else requestAndStart()
        }
    }

    private fun setPoint(p: GeoPoint, save: Boolean = true) {
        point = p
        val m = marker ?: Marker(map).also {
            it.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            it.title = "Tu będę"
            map.overlays.add(it)
            marker = it
        }
        m.position = p
        map.invalidate()
        info.text = String.format(Locale.US, "Wybrane: %.5f, %.5f", p.latitude, p.longitude)
        if (save) prefs.edit()
            .putString("lat", p.latitude.toString())
            .putString("lon", p.longitude.toString())
            .apply()
        if (MockLocationService.isRunning) sendToService(p)
    }

    private fun requestAndStart() {
        if (point == null) { toast("Najpierw kliknij na mapie miejsce"); return }
        val needed = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { !granted(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray()) else startMock()
    }

    private fun startMock() {
        val p = point ?: return
        if (!canMock()) { showMockDialog(); return }
        sendToService(p)
        setButton(true)
        ui.postDelayed({ setButton(MockLocationService.isRunning) }, 800)
    }

    private fun stopMock() {
        stopService(Intent(this, MockLocationService::class.java))
        setButton(false)
    }

    private fun sendToService(p: GeoPoint) {
        ContextCompat.startForegroundService(
            this,
            Intent(this, MockLocationService::class.java)
                .putExtra(MockLocationService.EXTRA_LAT, p.latitude)
                .putExtra(MockLocationService.EXTRA_LON, p.longitude)
        )
    }

    /** Sprawdza, czy Teleport jest wybrany jako aplikacja do pozorowania lokalizacji. */
    @Suppress("DEPRECATION")
    private fun canMock(): Boolean {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val test = "teleport_check"
        return try {
            lm.addTestProvider(test, false, false, false, false, false, false, false,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE)
            lm.removeTestProvider(test)
            true
        } catch (e: SecurityException) {
            false
        } catch (e: Exception) {
            true
        }
    }

    private fun showMockDialog() {
        AlertDialog.Builder(this)
            .setTitle("Jeszcze jeden krok")
            .setMessage(
                "Włącz Teleport w Opcjach programisty:\n\n" +
                "Opcje programisty → „Wybierz aplikację do pozorowania lokalizacji” → Teleport\n\n" +
                "Nie masz Opcji programisty? Ustawienia → Informacje o telefonie → " +
                "Informacje o oprogramowaniu → kliknij 7 razy w „Numer wersji”."
            )
            .setPositiveButton("Otwórz opcje programisty") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun setButton(running: Boolean) {
        startBtn.text = if (running) "STOP" else "START"
        startBtn.backgroundTintList = ColorStateList.valueOf(
            Color.parseColor(if (running) "#E53935" else "#43A047")
        )
        startBtn.setTextColor(Color.WHITE)
    }

    private fun granted(perm: String) =
        ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onResume() {
        super.onResume()
        map.onResume()
        setButton(MockLocationService.isRunning)
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
    }
}
